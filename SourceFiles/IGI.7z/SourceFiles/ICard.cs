﻿namespace Snap2
{
    public interface ICard
    {
        string CardSuit { get; set; }
        string CardValue { get; set; }
    }
}